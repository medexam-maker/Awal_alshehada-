export interface ContractSubject {
  index: number;
  name_ar: string;
  name_en: string;
  slug: string;
  category: 'common' | 'scientific' | 'literary';
  description_ar: string;
  iconName: string;
  defaultDurationMinutes: number;
}

export const TWELVE_CONTRACT_SUBJECTS: ContractSubject[] = [
  // 1-4: القسم العلمي (الكيمياء، الفيزياء، الأحياء، الرياضيات المتخصصة)
  {
    index: 1,
    name_ar: 'الكيمياء',
    name_en: 'Chemistry',
    slug: 'chemistry',
    category: 'scientific',
    description_ar: 'الكيمياء العامة والعضوية، التوازن الكيميائي، الديناميكا الحرارية، والكيمياء التحليلية.',
    iconName: 'FlaskConical',
    defaultDurationMinutes: 180,
  },
  {
    index: 2,
    name_ar: 'الفيزياء',
    name_en: 'Physics',
    slug: 'physics',
    category: 'scientific',
    description_ar: 'الميكانيكا والحركة، الكهرباء الساكنة والتيارية، المغناطيسية، والفيزياء الذرية والنووية.',
    iconName: 'Zap',
    defaultDurationMinutes: 180,
  },
  {
    index: 3,
    name_ar: 'الأحياء',
    name_en: 'Biology',
    slug: 'biology',
    category: 'scientific',
    description_ar: 'علم الخلية، وظائف الأعضاء، التكاثر، الوراثة والتطور، وعلم البيئة.',
    iconName: 'Dna',
    defaultDurationMinutes: 180,
  },
  {
    index: 4,
    name_ar: 'الرياضيات المتخصصة',
    name_en: 'Specialized Mathematics',
    slug: 'specialized-mathematics',
    category: 'scientific',
    description_ar: 'التفاضل والتكامل المتقدم، الهندسة التحليلية والمستوية، والمصفوفات والمتجهات.',
    iconName: 'Calculator',
    defaultDurationMinutes: 180,
  },

  // 5-8: القسم الأدبي (الجغرافيا، التاريخ، العلوم العسكرية، علوم الحاسوب)
  {
    index: 5,
    name_ar: 'الجغرافيا',
    name_en: 'Geography',
    slug: 'geography',
    category: 'literary',
    description_ar: 'جغرافية السودان الطبيعية والبشرية، قراءة وتفسير الخرائط الكنتورية، والدراسات البيئية.',
    iconName: 'Compass',
    defaultDurationMinutes: 150,
  },
  {
    index: 6,
    name_ar: 'التاريخ',
    name_en: 'History',
    slug: 'history',
    category: 'literary',
    description_ar: 'تاريخ السودان الحديث والمعاصر، الثورة المهدية، والحركات الوطنية والإفريقية.',
    iconName: 'Landmark',
    defaultDurationMinutes: 150,
  },
  {
    index: 7,
    name_ar: 'العلوم العسكرية',
    name_en: 'Military Science',
    slug: 'military-science',
    category: 'literary',
    description_ar: 'مبادئ الدفاع، العلوم والمهارات العسكرية الأساسية، والتنظيم والتكتيكات.',
    iconName: 'Shield',
    defaultDurationMinutes: 150,
  },
  {
    index: 8,
    name_ar: 'علوم الحاسوب',
    name_en: 'Computer Science',
    slug: 'computer-science',
    category: 'literary',
    description_ar: 'مبادئ البرمجة وتصميم الخوارزميات، نظم التشغيل، شبكات الحاسوب، وأمن المعلومات.',
    iconName: 'Cpu',
    defaultDurationMinutes: 150,
  },

  // 9-12: المواد الأساسية المشتركة (التربية الإسلامية، اللغة العربية، اللغة الإنجليزية، الرياضيات الأساسية)
  {
    index: 9,
    name_ar: 'التربية الإسلامية',
    name_en: 'Islamic Studies',
    slug: 'islamic-studies',
    category: 'common',
    description_ar: 'القرآن الكريم، علوم القرآن، العقيدة الإسلامية، الفقه، والسيرة النبوية.',
    iconName: 'BookOpen',
    defaultDurationMinutes: 150,
  },
  {
    index: 10,
    name_ar: 'اللغة العربية',
    name_en: 'Arabic Language',
    slug: 'arabic-language',
    category: 'common',
    description_ar: 'النحو والصرف، البلاغة، الأدب، النصوص المقررة، وقواعد الإملاء والإنشاء.',
    iconName: 'Feather',
    defaultDurationMinutes: 180,
  },
  {
    index: 11,
    name_ar: 'اللغة الإنجليزية',
    name_en: 'English Language',
    slug: 'english-language',
    category: 'common',
    description_ar: 'Sudan English Secondary Curriculum: Reading, grammar, composition, and literature.',
    iconName: 'Globe',
    defaultDurationMinutes: 150,
  },
  {
    index: 12,
    name_ar: 'الرياضيات الأساسية',
    name_en: 'Basic Mathematics',
    slug: 'basic-mathematics',
    category: 'common',
    description_ar: 'الجبر الأساسي، مبادئ الإحصاء والاحتمالات، وحساب المثلثات للشهادة الثانوية.',
    iconName: 'Divide',
    defaultDurationMinutes: 150,
  },
];
